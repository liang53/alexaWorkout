
exports.handler = function (event, context, callback) {
  var result = "Testing";
  callback(result);
};
